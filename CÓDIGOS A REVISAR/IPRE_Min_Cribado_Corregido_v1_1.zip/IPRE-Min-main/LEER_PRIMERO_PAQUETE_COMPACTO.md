# IPRE — Paquete único y reproducible (descarga compacta)

Este ZIP contiene el código de extracción de OpenAlex y Scopus, el importador de exportaciones manuales de WoS, el módulo de integración, el cribado común, las pruebas, la documentación y los **tres universos CSV de entrada** necesarios para reproducir el flujo.

Las matrices extensas de resultados históricos, los CSV intermedios y los resultados masivos del flujo unificado no se duplican dentro del ZIP para reducir el tamaño: **se regeneran en su equipo**. No se alteraron los datos de entrada. Se han conservado los JSON de páginas históricas de Scopus presentes en el archivo actualizado.

## Ejecutar desde la carpeta IPRE-Min-main

```bash
python flujo_unificado/main.py
```

Se generará `flujo_unificado/resultados` con normalización, consolidación, alertas, cribado automático, revisión humana y plantilla temática.

Para ejecutar pruebas:

```bash
python -m unittest discover -s flujo_unificado/pruebas -v
python -m unittest discover -s integracion_corpus/pruebas -v
```

Para nuevas extracciones, consulte `flujo_unificado/README.md` y ejecute `flujo_unificado/adquisicion.py` en su fuente correspondiente. No se necesitan claves API para reproducir el corpus a partir de los CSV archivados. Las exportaciones XLS originales de WoS no estaban incluidas en el repositorio suministrado y no se han inventado.

**Nota de integridad:** Este archivo reúne todas las piezas necesarias para ejecutar el flujo común con las entradas disponibles, pero no es una copia byte a byte del ZIP de 219 MB: omite tablas derivadas, matrices históricas voluminosas y archivos temporales. Para conservar exactamente todos esos archivos históricos debe utilizarse el ZIP original.
