# IPRE-M-DCC

Repositorio de código para la obtención y el procesamiento de datos bibliográficos provenientes de **OpenAlex**, **Scopus** y **Web of Science (WoS)**.

## Objetivo

Analizar la literatura sobre operaciones mineras a cielo abierto, con especial interés en la planificación, asignación y utilización de equipos y actividades auxiliares.

## Alcance del procesamiento

El flujo contempla la obtención y preparación de metadatos, deduplicación, filtrado temático, cribado de publicaciones y generación de resultados descriptivos, gráficos e informes. Se conservan las decisiones y los motivos de clasificación para revisar su evolución.

## Estado del proyecto

- **OpenAlex:** flujo de referencia desarrollado por Joaquín.
- **Scopus:** flujo adaptado y reproducción local comprobada. La validación humana independiente permanece pendiente.
- **Web of Science:** exportación manual y procesamiento local realizados, con cribado automático y resultados descriptivos generados. La revisión humana independiente permanece pendiente y la extracción mediante API continúa en evaluación.

Las cohortes se mantienen separadas y se utilizan criterios de cribado comparables. Las decisiones humanas de una fuente no se trasladan automáticamente a las demás.

## Ejecución y resultados

Las instrucciones de ejecución se encuentran en la documentación de cada paquete.

Scopus utiliza páginas JSON previamente guardadas para su reproducción local. WoS utiliza los archivos exportados manualmente. Estos procesos locales no requieren nuevas consultas a las respectivas API.

Las clasificaciones automáticas son resultados preliminares. La reproducción técnica no equivale a validación académica ni a revisión de texto completo.

## Documentación y datos

Los documentos y archivos asociados al proyecto se encuentran disponibles en [OneDrive](https://uccl0-my.sharepoint.com/:f:/g/personal/dpmunoz7_uc_cl/IgA3vjPfjPjIT4JlB-FXFnTdAfUi-_7iwYc_JCYEWEUt1ko?e=a4DZLa).

## Credenciales

El repositorio no debe contener claves de API ni otros datos de acceso.

## Integración de las tres bases de datos

Se incorporó `integracion_corpus/` para construir un corpus bibliográfico común **sin alterar los procesos originales**. El módulo usa las instantáneas guardadas de OpenAlex, Scopus y WoS, normaliza los metadatos, realiza una vinculación conservadora por DOI y título-año, conserva la procedencia de cada registro y genera alertas de revisión bibliográfica.

Desde la raíz del repositorio:

```powershell
py -3 integracion_corpus/main.py
```

Se generan dos conjuntos **provisionales** en `integracion_corpus/resultados/`: `universo` y `base_amplia`, ambos con matrices de correspondencias, alertas y manifiestos SHA-256. Las etiquetas temáticas específicas de cada fuente se conservan sin trasladar automáticamente decisiones entre bases. La guía completa y las limitaciones se encuentran en [`integracion_corpus/README.md`](integracion_corpus/README.md).

## Nuevo flujo recomendado: extracción independiente y cribado común

Se agregó [`flujo_unificado/`](flujo_unificado/README.md), que implementa el recorrido **OpenAlex (API) + Scopus (API) + WoS (exportación manual) → normalización → unificación → deduplicación interbase → cribado único sobre título/resumen → revisión humana → clasificación temática**.

**Ejecutar desde la raíz:**

```bash
python flujo_unificado/main.py
```

Usa instantáneas archivadas y no hace nuevas llamadas API. Los tres proyectos anteriores se mantienen completos para consulta y auditoría. La integración histórica `integracion_corpus/` sigue disponible, pero su carpeta `base_amplia` corresponde a cribados individuales previos y no debe confundirse con el **nuevo cribado común**. Las instrucciones para iniciar extracciones nuevas o importar exportaciones manuales WoS están en la guía de `flujo_unificado/`.

La clasificación temática definitiva está **pendiente de revisión humana**. Las coincidencias bibliográficas y las exclusiones automáticas tienen carácter provisional.
