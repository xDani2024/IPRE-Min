# Flujo unificado del corpus bibliográfico — IPRE

## Objetivo y orden de trabajo

**OpenAlex (API), Scopus (API) y WoS (exportación manual) se obtienen independientemente**, con consultas y filtros de recuperación documentados. Después se efectúan, sobre todos los registros disponibles, **normalización → unificación → deduplicación interbase → cribado común (título y resumen) → revisión humana → clasificación temática**.

Las etiquetas temáticas no se fijan antes de la unificación. Las reglas y decisiones de los cribados anteriores por base (v6-v9) se mantienen intactas como antecedentes para comparar, **pero NO determinan la inclusión en el nuevo corpus**.

### Esquema de pasos

```text
OpenAlex: API ---------┐
Scopus:   API ---------+--> entradas originales conservadas
WoS:     archivos ----┘            |
                       normalización de campos
                                |
                    unificación de las 3 fuentes
                                |
                      deduplicación por DOI y título-año
                       (con alertas para revisión)
                                |
               cribado inicial COMÚN sobre título y abstract
                                |
                         revisión humana (PENDIENTE)
                                |
                  clasificación temática (PENDIENTE)
``` 

## Reproducir con el repositorio entregado

Desde la carpeta `IPRE-Min-main`, ejecute:

```bash
python flujo_unificado/main.py
```

Esto **no requiere internet ni claves**: usa los tres universos archivados antes de sus cribados temáticos individuales. Al final encontrará los resultados en `flujo_unificado/resultados`.

**Entradas por defecto:** OpenAlex `universo_openalex.csv` (9.534), Scopus `universo_scopus_deduplicado.csv` (9.547) y WoS `01_registros_unicos_normalizados.csv` (5.071). Cada fuente ya aplicó algunos controles técnicos y su propia deduplicación, por lo que los 24.152 registros de entrada **no son el total bruto de resultados de búsqueda** ni implican una captura simultánea de las tres bases. Se conservan recuentos y archivos de origen.

## Para utilizar nuevas extracciones (sin ejecutar cribados de cada fuente)

Interfaz común para invocar los extractores existentes, manteniendo internamente sus distintas APIs:

```bash
python flujo_unificado/adquisicion.py --fuente scopus --modo piloto --salida ejecuciones/scopus_2026
python flujo_unificado/adquisicion.py --fuente openalex --modo completo --salida ejecuciones/openalex_2026
python flujo_unificado/adquisicion.py --fuente wos --carpeta-wos exportaciones_wos --salida ejecuciones/wos_2026
```

OpenAlex requiere `OPENALEX_API_KEY`, Scopus requiere `SCOPUS_API_KEY` o ingreso interactivo. El extractor **original OpenAlex no tiene piloto**, por lo que aquí no se simula uno. No se ejecutaron nuevas consultas de red para preparar este paquete. Los extractores siguen usando sus parámetros, consultas y controles originales; la interfaz común solo estandariza cómo invocarlos. Guarde las nuevas consultas, fechas, conteos y criterios en la bitácora.

Tras obtener universos nuevos, ejecutar el procesamiento común con sus rutas (antes de cualquier cribado temático):

```bash
python flujo_unificado/main.py --openalex-csv ejecuciones/openalex_2026/universo_openalex.csv --scopus-csv ejecuciones/scopus_2026/universo_scopus_deduplicado.csv --wos-exportaciones exportaciones_wos --salida ejecuciones/corpus_2026
```

**Nota importante sobre Scopus:** el lanzador común prepara `universo_scopus_deduplicado.csv` directamente desde las páginas guardadas, **sin aplicar cribado temático por fuente**. El modo piloto se rotula como parcial y no reemplaza una extracción completa. Antes de analizar la cohorte, revise el manifiesto de páginas/consultas y complete el ciclo con diez ramas.

WoS también puede ingresar como `--wos-csv ruta/al/universo.csv` si el archivo ya fue normalizado. `--wos-exportaciones` acepta CSV UTF-8, XLSX y XLS; para XLSX se requiere `openpyxl` y para XLS se requiere `xlrd` (instalación con `pip install openpyxl xlrd`). No se importan silenciosamente archivos sin títulos ni se combinan UID repetidos sin revisión. Conservar la fecha de búsqueda, todas las consultas WoS, filtros, lotes exportados, número de resultados y verificaciones de cobertura.

## Estructura de resultados

- `02_integracion_y_deduplicacion/`: matriz normalizada, corpus provisional sin duplicados, correspondencias de ID, alertas, fuentes y huellas SHA-256.
- `03_cribado_comun/`: cribado automático común y subconjuntos de candidatos, pendientes o propuestas de exclusión.
- `04_revision_humana/`: plantilla con **todas** las publicaciones para revisión independiente (nada se elimina automáticamente de forma irreversible).
- `05_clasificacion_posterior/`: plantilla temática, **sin etiquetas definitivas**.
- `06_auditoria/`: resumen completo, parámetros, recuentos, limitaciones y SHA-256 de salidas.

## Precauciones metodológicas

1. **Reproducible desde instantáneas guardadas** no significa idéntica extracción en otra fecha: los catálogos y licencias cambian.
2. **Mismos criterios en el cribado:** el motor solo consulta título, resumen y tipo de documento. No utiliza palabras clave o topics exclusivos de OpenAlex. Los diccionarios proceden del extractor original OpenAlex, pero esta adaptación común aún no ha sido calibrada con revisión humana conjunta; es una primera propuesta.
3. Las coincidencias DOI/título-año son conservadoras y pueden producir **alertas**; revise las alertas antes de publicar cifras finales.
4. Los registros WoS exportados manualmente son válidos para esta integración siempre que exista documentación suficiente de consultas, fechas, filtros, archivos y cobertura. Los diez XLS originales WoS **no estaban incluidos** en el repositorio recibido, por lo que la ejecución de demostración emplea el CSV normalizado de WoS.
5. Las etiquetas temáticas (3–5 grandes grupos, 6–8 temas específicos, objetivo, metodología y datos) deben consensuarse **después** del cribado y la revisión de inclusión, no confundirse con señales automáticas de detección.
6. Los 3 universos tienen filtros documentales propios anteriores (artículo/revisión, acceso a resúmenes, etc.). Si se necesita un conteo PRISMA exacto desde resultados brutos, se deben incorporar también las exportaciones/descargas crudas y sus contadores de origen.

## Pruebas

```bash
python -m unittest discover -s flujo_unificado/pruebas -v
python -m unittest discover -s integracion_corpus/pruebas -v
```
