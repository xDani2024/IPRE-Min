"""Cribado inicial uniforme sobre título + abstract del corpus consolidado.

Es una propuesta AUTOMÁTICA y AUDITABLE; no equivale a revisión humana ni
reproduce el cribado calibrado v6/v8/v9 de OpenAlex.
"""
from __future__ import annotations
import importlib.util
import re
import unicodedata
from pathlib import Path
from functools import lru_cache

ROOT = Path(__file__).resolve().parents[1]
OA_ORIGINAL = ROOT/'Código OpenAlex/IPRE_codigo_y_datos_v9/01_extraccion_y_filtro/01_extraer_openalex.py'

@lru_cache(maxsize=1)
def diccionarios_originales():
    spec = importlib.util.spec_from_file_location('ipre_diccionarios_abiertos', OA_ORIGINAL)
    if spec is None or spec.loader is None:
        raise FileNotFoundError(OA_ORIGINAL)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def normal(texto):
    texto = unicodedata.normalize('NFKD', str(texto or '').lower())
    texto = ''.join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r'\s+', ' ', texto).strip()


@lru_cache(maxsize=1024)
def patron(frases: tuple[str, ...]):
    terminos = [normal(t) for t in frases if normal(t)]
    if not terminos:
        return None
    return re.compile(r'(?<![a-z0-9])(?:' + '|'.join(re.escape(t) for t in sorted(set(terminos),key=len,reverse=True)) + r')(?![a-z0-9])')


def coincide(texto, frases):
    p = patron(tuple(frases))
    return bool(p and p.search(texto))


def categorias(texto, diccionario):
    return sorted(k for k, terms in diccionario.items() if coincide(texto, terms))


def evaluar(publicacion):
    """Usa SOLO título y resumen para evitar sesgo de keywords/topics entre APIs."""
    d = diccionarios_originales()
    titulo = normal(publicacion.get('titulo'))
    resumen = normal(publicacion.get('resumen'))
    todo = f'{titulo} {resumen}'
    tipo = normal(publicacion.get('tipo_documento'))
    procesos = categorias(todo, d.PROCESS_TERMS)
    equipos = categorias(todo, d.EQUIPMENT_TERMS)
    focos = categorias(todo, d.FOCUS_TERMS)

    if not titulo:
        estado, razones = 'PENDIENTE_REVISION', ['sin_titulo']
    elif not resumen:
        estado, razones = 'PENDIENTE_REVISION', ['sin_resumen']
    elif not tipo:
        estado, razones = 'PENDIENTE_REVISION', ['tipo_no_informado']
    elif not any(part.strip() in {'article', 'review'} for part in tipo.split(';')):
        estado, razones = 'EXCLUSION_PROPUESTA', ['tipo_documental_no_admitido']
    else:
        razones = []
        hard = coincide(titulo, d.HARD_EXCLUSION_TITLE_TERMS)
        if hard:
            razones.append('metodo_subterraneo_fuera_de_alcance')
        if coincide(titulo, d.EXCLUSION_TITLE_TERMS) and not coincide(titulo, d.EXCLUSION_OVERRIDE_TITLE_TERMS):
            razones.append('tema_excluido_en_titulo')
        tiene_contexto_titulo = coincide(titulo, d.OPEN_PIT_PHRASES)
        senal_titulo = bool(categorias(titulo, d.DIRECT_OPERATIONAL_TERMS) or
                            categorias(titulo, d.EQUIPMENT_TERMS) or
                            (tiene_contexto_titulo and (
                              categorias(titulo, d.PROCESS_TERMS) or categorias(titulo, d.FOCUS_TERMS))))
        senal_combinada = (coincide(todo, d.OPEN_PIT_PHRASES) and bool(
            categorias(todo, d.DIRECT_OPERATIONAL_TERMS) or
            (equipos and (procesos or focos))))
        # Esta regla no usa ramas de búsqueda ni topics específicos de OpenAlex.
        if not (senal_titulo or senal_combinada or
                len(categorias(todo, d.DIRECT_OPERATIONAL_TERMS)) >= 2):
            razones.append('foco_operacional_no_detectado')
        estado = 'CANDIDATO' if not razones else 'EXCLUSION_PROPUESTA'
    return {
        'cribado_automatico': estado,
        'motivos_cribado': '|'.join(razones),
        'procesos_sugeridos': '|'.join(procesos),
        'equipos_sugeridos': '|'.join(equipos),
        'focos_sugeridos': '|'.join(focos),
        'decision_humana': '',
        'motivo_decision_humana': '',
        'revisor': '',
        'fecha_revision': '',
    }
