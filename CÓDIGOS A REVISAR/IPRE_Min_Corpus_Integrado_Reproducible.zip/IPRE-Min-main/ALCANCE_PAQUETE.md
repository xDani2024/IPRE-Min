# Alcance del paquete integrado

Este ZIP es una **versión compacta y ejecutable del módulo de integración**. Incluye los códigos y archivos CSV necesarios para repetir la normalización y consolidación bibliográfica de las tres fuentes, además de las salidas comprobadas.

Los demás scripts, páginas JSON originales de Scopus, resultados históricos, auditores y documentos de las tres cohortes permanecen en el ZIP original `IPRE-Min-main.zip` entregado por el equipo. **No se reemplaza ese archivo ni se afirma que aquí estén todos los elementos para repetir las consultas originales a las API o reconstruir WoS desde XLS**.

Para reconstruir el corpus **desde los CSV incluidos**, ejecutar `python integracion_corpus/main.py` desde esta carpeta. La documentación metodológica detallada está en `integracion_corpus/README.md`.

Los scripts originales de extracción se mantienen como material de referencia y pueden requerir sus propios insumos externos. No deben interpretarse como un flujo autónomo reconstruido en este paquete compacto.
